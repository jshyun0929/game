#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
revision=a030f552f452158a2db64fdb32b490fa19c0b48d
curl -fSL "https://codeload.github.com/brunodev85/winlator-app/tar.gz/$revision" -o upstream-source.tar.gz
curl -fSL 'https://github.com/brunodev85/winlator/releases/download/v11.2.0/Winlator_11.2.apk' -o upstream.apk
sha256sum -c upstream.sha256
mkdir -p project
tar --strip-components=1 -xf upstream-source.tar.gz -C project
cp -a overlay/. project/
python3 - <<'PY'
import zipfile
from pathlib import Path
with zipfile.ZipFile('upstream.apk') as apk:
    for name in apk.namelist():
        if name.startswith('lib/arm64-v8a/') and name.endswith('.so') and 'zstd-jni' not in name:
            library = Path('project/app/src/main/jniLibs') / name.removeprefix('lib/')
            library.parent.mkdir(parents=True, exist_ok=True)
            library.write_bytes(apk.read(name))
PY
