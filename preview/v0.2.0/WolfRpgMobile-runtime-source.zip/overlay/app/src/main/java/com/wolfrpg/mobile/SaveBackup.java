package com.wolfrpg.mobile;

import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.StandardCopyOption;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

final class SaveBackup {
    private static final String MIME = "application/octet-stream";

    static int backup(GameFiles game, File archive) throws IOException {
        File temporary = File.createTempFile("backup-", ".zip", archive.getParentFile());
        try {
            int count;
            try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(temporary))) {
                count = copySaves(game, game.root, "", zip);
                GameFiles.Item saves = game.find(game.root, "Save");
                if (saves != null && saves.directory()) {
                    count += copySaves(game, saves.uri(), "Save/", zip);
                }
            }
            if (count == 0) throw new IOException("게임 폴더와 Save 폴더에서 .sav 파일을 찾지 못했어요.");
            Files.move(temporary.toPath(), archive.toPath(),
                StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            return count;
        } finally {
            temporary.delete();
        }
    }

    static int backupLocal(File game, File archive) throws IOException {
        File temporary = File.createTempFile("backup-", ".zip", archive.getParentFile());
        try {
            int count;
            try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(temporary))) {
                count = copyLocalSaves(game, "", zip);
                File folder = findLocal(game, "Save");
                if (folder != null && Files.isDirectory(folder.toPath(), LinkOption.NOFOLLOW_LINKS)) {
                    count += copyLocalSaves(folder, "Save/", zip);
                }
            }
            if (count == 0) throw new IOException("게임 복사본에서 .sav 파일을 찾지 못했어요.");
            Files.move(temporary.toPath(), archive.toPath(),
                StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            return count;
        } finally {
            temporary.delete();
        }
    }

    static int restoreLocal(File game, File archive) throws IOException {
        int count = 0;
        try (ZipFile zip = new ZipFile(archive)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                boolean inSave = entry.getName().startsWith("Save/");
                String name = inSave ? entry.getName().substring(5) : entry.getName();
                if (!valid(name) || entry.isDirectory()) throw new IOException("백업 파일 형식이 올바르지 않아요.");
                File destination = game;
                if (inSave) {
                    destination = findLocal(game, "Save");
                    if (destination == null) {
                        destination = new File(game, "Save");
                        Files.createDirectory(destination.toPath());
                    }
                    if (!Files.isDirectory(destination.toPath(), LinkOption.NOFOLLOW_LINKS)) {
                        throw new IOException("Save 폴더에 접근할 수 없어요.");
                    }
                }
                if (findLocal(destination, name) != null) continue;
                File temporary = File.createTempFile("save-", ".tmp", destination);
                try {
                    try (InputStream input = zip.getInputStream(entry);
                         OutputStream output = new FileOutputStream(temporary)) {
                        copy(input, output);
                    }
                    Files.move(temporary.toPath(), new File(destination, name).toPath());
                    count++;
                } finally {
                    temporary.delete();
                }
            }
        }
        return count;
    }

    private static int copyLocalSaves(File directory, String prefix, ZipOutputStream zip) throws IOException {
        File[] files = directory.listFiles();
        if (files == null) throw new IOException("세이브 폴더를 읽을 수 없어요.");
        int count = 0;
        for (File file : files) {
            if (!valid(file.getName()) || !Files.isRegularFile(file.toPath(), LinkOption.NOFOLLOW_LINKS)) continue;
            zip.putNextEntry(new ZipEntry(prefix + file.getName()));
            try (InputStream input = Files.newInputStream(file.toPath())) {
                copy(input, zip);
            }
            zip.closeEntry();
            count++;
        }
        return count;
    }

    private static File findLocal(File directory, String name) throws IOException {
        File[] files = directory.listFiles();
        if (files == null) throw new IOException("세이브 폴더를 읽을 수 없어요.");
        for (File file : files) {
            if (file.getName().equalsIgnoreCase(name)) return file;
        }
        return null;
    }

    static int restoreMissing(GameFiles game, File archive) throws IOException {
        int count = 0;
        try (ZipFile zip = new ZipFile(archive)) {
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                boolean inSave = entry.getName().startsWith("Save/");
                String name = inSave ? entry.getName().substring(5) : entry.getName();
                if (!valid(name) || entry.isDirectory()) throw new IOException("백업 파일 형식이 올바르지 않아요.");

                Uri parent = game.root;
                if (inSave) {
                    GameFiles.Item saves = game.find(game.root, "Save");
                    if (saves != null && !saves.directory()) {
                        throw new IOException("Save 이름으로 된 파일이 이미 있어요.");
                    }
                    parent = saves == null
                        ? game.create(game.root, DocumentsContract.Document.MIME_TYPE_DIR, "Save")
                        : saves.uri();
                }
                if (game.find(parent, name) != null) continue;
                Uri target = game.create(parent, MIME, name);
                try (InputStream input = zip.getInputStream(entry);
                     OutputStream output = game.resolver.openOutputStream(target, "w")) {
                    if (output == null) throw new IOException("복원 파일을 열 수 없어요.");
                    copy(input, output);
                } catch (IOException | RuntimeException ex) {
                    try {
                        DocumentsContract.deleteDocument(game.resolver, target);
                    } catch (IOException | RuntimeException cleanup) {
                        ex.addSuppressed(cleanup);
                    }
                    throw ex;
                }
                count++;
            }
        }
        return count;
    }

    private static int copySaves(GameFiles game, Uri directory, String prefix, ZipOutputStream zip)
        throws IOException {
        int count = 0;
        for (GameFiles.Item file : game.children(directory)) {
            if (file.directory() || !valid(file.name())) continue;
            zip.putNextEntry(new ZipEntry(prefix + file.name()));
            try (InputStream input = game.open(file.uri())) {
                copy(input, zip);
            }
            zip.closeEntry();
            count++;
        }
        return count;
    }

    private static boolean valid(String name) {
        return name != null && !name.contains("/") && !name.contains("\\") && GameFiles.saveName(name);
    }

    private static void copy(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[32768];
        int read;
        while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
    }
}
