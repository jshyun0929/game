package com.wolfrpg.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int PICK_FOLDER = 10;
    private static final int BG = 0xff111521;
    private static final int CARD = 0xff202638;
    private static final int LIGHT = 0xfff3efff;
    private static final int MUTED = 0xffbfbed3;
    private static final int ACCENT = 0xffc3b4ff;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    private final List<Game> games = new ArrayList<>();
    private SharedPreferences preferences;
    private LinearLayout content;
    private TextView status;
    private ProgressBar progress;
    private String selectedId;
    private String relinkId;
    private boolean busy;

    record Game(String id, String name, String uri, String architecture) {}

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("library", MODE_PRIVATE);
        if (state != null) {
            selectedId = state.getString("selected");
            relinkId = state.getString("relink");
        }
        render();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putString("selected", selectedId);
        state.putString("relink", relinkId);
    }

    @Override protected void onRestart() {
        super.onRestart();
        if (!busy) render();
    }

    private void render() {
        load();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            content.setPadding(dp(22), dp(16) + insets.getSystemWindowInsetTop(),
                dp(22), dp(24) + insets.getSystemWindowInsetBottom());
            return WindowInsets.CONSUMED;
        });
        setContentView(scroll);

        Game selected = game(selectedId);
        if (selected == null) {
            label(content, "울프 RPG", 36, LIGHT, true);
            label(content, "게임 라이브러리", 17, MUTED, false);
            button(content, "＋ 게임 폴더 추가", true, () -> pick(null));
            statusView();
            if (games.isEmpty()) {
                LinearLayout panel = card();
                label(panel, "등록된 게임이 없어요", 20, LIGHT, true);
                label(panel, "압축을 푼 뒤 Game.exe가 들어 있는 폴더를 선택하세요.", 15, MUTED, false);
            }
            for (Game item : games) {
                LinearLayout panel = card();
                label(panel, item.name(), 22, LIGHT, true);
                label(panel, item.architecture(), 14, MUTED, false);
                button(panel, "게임 열기", false, () -> {
                    selectedId = item.id();
                    render();
                });
            }
        } else {
            button(content, "‹ 라이브러리", false, () -> {
                selectedId = null;
                render();
            });
            label(content, selected.name(), 30, LIGHT, true);
            label(content, "Game.exe · " + selected.architecture(), 15, MUTED, false);
            statusView();

            LinearLayout runtime = card();
            label(runtime, "Windows 게임 실행", 19, LIGHT, true);
            button(runtime, "실행", true, () -> play(selected));
            String renderer = renderer(selected);
            button(runtime, "그래픽 · " + (renderer.equals("dxvk") ? "DXVK" : "WineD3D"),
                false, () -> selectRenderer(selected));

            LinearLayout saves = card();
            label(saves, "세이브 관리", 19, LIGHT, true);
            label(saves, "게임 폴더와 Save 폴더 바로 아래의 .sav 파일을 앱에 백업합니다.", 14, MUTED, false);
            button(saves, "세이브 백업", false, () -> backup(selected));
            Button restore = button(saves, "누락된 세이브 복원", false, () -> restore(selected));
            restore.setEnabled(archive(selected).isFile());

            LinearLayout folder = card();
            label(folder, "게임 폴더", 19, LIGHT, true);
            if (!EmbeddedRuntime.gameDirectory(this, selected.id()).isDirectory()) {
                button(folder, "폴더 다시 연결", false, () -> pick(selected.id()));
            } else {
                label(folder, "실행 중에 만든 세이브는 앱의 게임 복사본에 저장됩니다.", 14, MUTED, false);
            }
            button(folder, "라이브러리에서 제거", false, () -> confirmRemove(selected));
        }
    }

    private void statusView() {
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setVisibility(View.GONE);
        content.addView(progress, new LinearLayout.LayoutParams(-1, dp(6)));
        status = label(content, "", 14, ACCENT, false);
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        status.setVisibility(View.GONE);
    }

    private void pick(String id) {
        relinkId = id;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, PICK_FOLDER);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FOLDER) return;
        String replace = relinkId;
        relinkId = null;
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri tree = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        run("게임 폴더 확인 중…", () -> register(tree, flags, replace));
    }

    private String register(Uri tree, int flags, String replace) throws IOException, JSONException {
        JSONArray data = storedGames();
        JSONObject previous = null;
        for (int i = 0; i < data.length(); i++) {
            JSONObject row = data.getJSONObject(i);
            if (row.getString("uri").equals(tree.toString()) && !row.getString("id").equals(replace)) {
                return "이미 등록한 게임 폴더예요.";
            }
            if (row.getString("id").equals(replace)) previous = row;
        }

        GameFiles files = new GameFiles(getContentResolver(), tree);
        GameFiles.Item exe = files.find(files.root, "Game.exe");
        if (exe == null || exe.directory()) {
            throw new IOException("이 폴더에 Game.exe가 없어요. 파일이 바로 들어 있는 폴더를 선택하세요.");
        }
        JSONObject row = new JSONObject()
            .put("id", previous == null ? UUID.randomUUID().toString() : replace)
            .put("name", files.name()).put("uri", tree.toString()).put("architecture", files.inspect(exe));

        boolean sameFolder = previous != null && previous.getString("uri").equals(tree.toString());
        getContentResolver().takePersistableUriPermission(tree, flags);
        try {
            if (previous == null) {
                data.put(row);
            } else {
                for (int i = 0; i < data.length(); i++) {
                    if (data.getJSONObject(i).getString("id").equals(replace)) data.put(i, row);
                }
            }
            store(data);
        } catch (IOException | JSONException | RuntimeException ex) {
            if (!sameFolder) release(tree);
            throw ex;
        }
        if (previous != null && !sameFolder) release(Uri.parse(previous.getString("uri")));
        return previous == null ? "게임을 등록했어요." : "게임 폴더를 다시 연결했어요.";
    }

    private void play(Game item) {
        run("게임 파일과 Windows 환경을 준비 중…", () -> {
            Intent launch = EmbeddedRuntime.prepare(this, files(item), item.id(), renderer(item));
            runOnUiThread(() -> {
                if (!isDestroyed()) startActivity(launch);
            });
            return "게임 실행을 요청했어요.";
        });
    }

    private String renderer(Game item) {
        return preferences.getString("renderer-" + item.id(), "wined3d");
    }

    private void selectRenderer(Game item) {
        String[] labels = {"WineD3D", "DXVK"};
        String[] values = {"wined3d", "dxvk"};
        new AlertDialog.Builder(this).setTitle("그래픽 방식")
            .setSingleChoiceItems(labels, renderer(item).equals("dxvk") ? 1 : 0, (dialog, which) -> {
                preferences.edit().putString("renderer-" + item.id(), values[which]).apply();
                dialog.dismiss();
                render();
            })
            .setNegativeButton("취소", null).show();
    }

    private void backup(Game item) {
        Runnable action = () -> run("세이브 백업 중…", () -> {
            File copy = EmbeddedRuntime.gameDirectory(this, item.id());
            int count = copy.isDirectory() ? SaveBackup.backupLocal(copy, archive(item))
                : SaveBackup.backup(files(item), archive(item));
            return "세이브 " + count + "개를 백업했어요.";
        });
        if (!archive(item).exists()) {
            action.run();
            return;
        }
        new AlertDialog.Builder(this).setTitle("최신 세이브로 다시 백업할까요?")
            .setMessage("백업에 성공하면 이전 백업을 교체합니다.")
            .setNegativeButton("취소", null).setPositiveButton("백업", (d, w) -> action.run()).show();
    }

    private void restore(Game item) {
        run("세이브 복원 중…", () -> {
            File copy = EmbeddedRuntime.gameDirectory(this, item.id());
            int count = copy.isDirectory() ? SaveBackup.restoreLocal(copy, archive(item))
                : SaveBackup.restoreMissing(files(item), archive(item));
            return count == 0 ? "복원할 누락 파일이 없어요." : "세이브 " + count + "개를 복원했어요.";
        });
    }

    private void confirmRemove(Game item) {
        new AlertDialog.Builder(this).setTitle("게임을 목록에서 제거할까요?")
            .setMessage("앱에 저장한 이 게임의 복사본과 세이브 백업을 삭제합니다.")
            .setNegativeButton("취소", null).setPositiveButton("제거", (d, w) -> {
                selectedId = null;
                run("게임 제거 중…", () -> {
                    JSONArray data = storedGames();
                    for (int i = 0; i < data.length(); i++) {
                        if (data.getJSONObject(i).getString("id").equals(item.id())) {
                            data.remove(i);
                            break;
                        }
                    }
                    File copy = EmbeddedRuntime.gameDirectory(this, item.id());
                    if (copy.exists()) EmbeddedRuntime.remove(copy);
                    store(data);
                    preferences.edit().remove("renderer-" + item.id()).apply();
                    release(Uri.parse(item.uri()));
                    if (archive(item).exists() && !archive(item).delete()) {
                        return "게임을 제거했지만 앱 내부 백업을 삭제하지 못했어요.";
                    }
                    return "게임을 목록에서 제거했어요.";
                });
            }).show();
    }

    private JSONArray storedGames() throws JSONException {
        return new JSONArray(preferences.getString("games", "[]"));
    }

    private void store(JSONArray data) throws IOException {
        if (!preferences.edit().putString("games", data.toString()).commit()) {
            throw new IOException("게임 목록을 저장할 수 없어요.");
        }
    }

    private void load() {
        games.clear();
        try {
            JSONArray data = storedGames();
            for (int i = 0; i < data.length(); i++) {
                JSONObject row = data.getJSONObject(i);
                games.add(new Game(row.getString("id"), row.getString("name"),
                    row.getString("uri"), row.getString("architecture")));
            }
        } catch (JSONException ex) {
            android.util.Log.e("WolfRpgMobile", "Could not read library", ex);
        }
    }

    private Game game(String id) {
        for (Game item : games) {
            if (item.id().equals(id)) return item;
        }
        return null;
    }

    private File archive(Game item) {
        return new File(getFilesDir(), "save-" + item.id() + ".zip");
    }

    private GameFiles files(Game item) {
        return new GameFiles(getContentResolver(), Uri.parse(item.uri()));
    }

    private void release(Uri tree) {
        try {
            for (UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
                if (!permission.getUri().equals(tree)) continue;
                int flags = 0;
                if (permission.isReadPermission()) flags |= Intent.FLAG_GRANT_READ_URI_PERMISSION;
                if (permission.isWritePermission()) flags |= Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
                getContentResolver().releasePersistableUriPermission(tree, flags);
                break;
            }
        } catch (SecurityException ex) {
            android.util.Log.w("WolfRpgMobile", "Folder grant already unavailable", ex);
        }
    }

    interface Operation {
        String run() throws IOException, JSONException;
    }

    private void run(String message, Operation operation) {
        if (busy) return;
        busy = true;
        disableButtons(content);
        progress.setVisibility(View.VISIBLE);
        showStatus(message);
        IO.execute(() -> {
            String result;
            try {
                result = operation.run();
            } catch (SecurityException ex) {
                result = "폴더 접근 권한을 확인하세요. 게임 화면에서 폴더를 다시 연결할 수 있어요.";
            } catch (IOException ex) {
                result = ex.getMessage();
            } catch (JSONException | RuntimeException ex) {
                android.util.Log.e("WolfRpgMobile", "Operation failed", ex);
                result = "작업을 완료하지 못했어요. 폴더와 저장 공간을 확인하세요.";
            }
            String feedback = result;
            runOnUiThread(() -> {
                if (isDestroyed()) return;
                busy = false;
                render();
                showStatus(feedback == null ? "작업을 완료하지 못했어요." : feedback);
            });
        });
    }

    private void disableButtons(LinearLayout layout) {
        for (int i = 0; i < layout.getChildCount(); i++) {
            View child = layout.getChildAt(i);
            if (child instanceof Button button) button.setEnabled(false);
            if (child instanceof LinearLayout nested) disableButtons(nested);
        }
    }

    private void showStatus(String message) {
        status.setText(message);
        status.setVisibility(View.VISIBLE);
    }

    private LinearLayout card() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(14));
        panel.setBackground(background(CARD, 18));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(14);
        content.addView(panel, params);
        return panel;
    }

    private TextView label(LinearLayout parent, String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text.setPadding(0, dp(4), 0, dp(7));
        parent.addView(text, new LinearLayout.LayoutParams(-1, -2));
        return text;
    }

    private Button button(LinearLayout parent, String text, boolean primary, Runnable action) {
        Button button = new Button(this);
        button.setAllCaps(false);
        button.setText(text);
        button.setTextSize(15);
        button.setTextColor(primary ? Color.BLACK : LIGHT);
        button.setMinHeight(dp(48));
        int fill = primary ? ACCENT : 0xff353c55;
        button.setBackground(new android.graphics.drawable.RippleDrawable(
            ColorStateList.valueOf(0x33ffffff), background(fill, 12), null));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(8);
        parent.addView(button, params);
        if (action != null) button.setOnClickListener(v -> action.run());
        else button.setAlpha(0.45f);
        return button;
    }

    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }
}
