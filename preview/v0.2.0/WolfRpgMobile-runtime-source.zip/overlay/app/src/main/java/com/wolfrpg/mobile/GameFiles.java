package com.wolfrpg.mobile;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class GameFiles {
    record Item(Uri uri, String name, String mime) {
        boolean directory() {
            return Document.MIME_TYPE_DIR.equals(mime);
        }
    }

    private static final String[] COLUMNS = {
        Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE
    };

    final ContentResolver resolver;
    final Uri tree;
    final Uri root;

    GameFiles(ContentResolver resolver, Uri tree) {
        this.resolver = resolver;
        this.tree = tree;
        root = document(DocumentsContract.getTreeDocumentId(tree));
    }

    String name() throws IOException {
        try (Cursor cursor = resolver.query(root, COLUMNS, null, null, null)) {
            if (cursor == null || !cursor.moveToFirst()) {
                throw new IOException("게임 폴더를 열 수 없어요.");
            }
            return cursor.getString(1);
        }
    }

    List<Item> children(Uri directory) throws IOException {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree, DocumentsContract.getDocumentId(directory));
        List<Item> files = new ArrayList<>();
        try (Cursor cursor = resolver.query(children, COLUMNS, null, null, null)) {
            if (cursor == null) throw new IOException("폴더 내용을 읽을 수 없어요.");
            while (cursor.moveToNext()) {
                files.add(new Item(document(cursor.getString(0)), cursor.getString(1), cursor.getString(2)));
            }
        }
        return files;
    }

    Item find(Uri parent, String name) throws IOException {
        for (Item file : children(parent)) {
            if (name.equalsIgnoreCase(file.name())) return file;
        }
        return null;
    }

    InputStream open(Uri file) throws IOException {
        InputStream input = resolver.openInputStream(file);
        if (input == null) throw new IOException("파일을 열 수 없어요.");
        return input;
    }

    String inspect(Item executable) throws IOException {
        try (DataInputStream bytes = new DataInputStream(open(executable.uri()))) {
            byte[] header = new byte[64];
            bytes.readFully(header);
            if (header[0] != 'M' || header[1] != 'Z') {
                return "실행 파일 형식 확인 불가";
            }
            long peOffset = (header[60] & 255L) | ((header[61] & 255L) << 8)
                | ((header[62] & 255L) << 16) | ((header[63] & 255L) << 24);
            if (peOffset < 64 || peOffset > 1048576) return "PE 헤더 확인 불가";
            bytes.readFully(new byte[(int) peOffset - 64]);
            byte[] pe = new byte[6];
            bytes.readFully(pe);
            if (pe[0] != 'P' || pe[1] != 'E' || pe[2] != 0 || pe[3] != 0) {
                return "PE 헤더 확인 불가";
            }
            int machine = (pe[4] & 255) | ((pe[5] & 255) << 8);
            return switch (machine) {
                case 0x014c -> "Windows x86 · 32비트";
                case 0x8664 -> "Windows x64 · 64비트";
                case 0xaa64 -> "Windows ARM64";
                default -> "Windows PE · " + Integer.toHexString(machine);
            };
        } catch (java.io.EOFException ex) {
            return "PE 헤더 확인 불가";
        }
    }

    Uri create(Uri parent, String mime, String name) throws IOException {
        Uri made = DocumentsContract.createDocument(resolver, parent, mime, name);
        if (made == null) throw new IOException("파일을 만들 수 없어요.");
        return made;
    }

    static boolean saveName(String name) {
        return name.toLowerCase(Locale.ROOT).endsWith(".sav");
    }

    private Uri document(String id) {
        return DocumentsContract.buildDocumentUriUsingTree(tree, id);
    }
}
