# 울프 RPG 0.2.1 실행 엔진 테스트

`prepare.sh`는 Winlator 11.2에 사용한 고정 소스와 공식 APK를 받아 SHA-256을 확인하고, 이 앱의 변경 사항을 적용합니다. `project`에서 JDK 17, Android SDK 35 및 Gradle 8.9로 `gradle :app:assembleDebug`를 실행하세요. 기존 APK 업데이트에는 같은 서명 키가 필요합니다.

Winlator 소스와 라이선스는 https://github.com/brunodev85/winlator-app/tree/a030f552f452158a2db64fdb32b490fa19c0b48d 에 있습니다. 추가 구성 요소와 관련 소스는 https://github.com/brunodev85/winlator 및 프로젝트의 크레딧을 참조하세요. Android ARM64 네이티브 라이브러리는 공식 Winlator 11.2 APK의 바이너리를 사용합니다.

게임 목록에서 실행을 누르면 선택한 게임 폴더가 앱 내부로 복사되고, Wine·Box64 초기화 후 앱 안에서 게임을 엽니다. 실행 중 세이브는 앱의 게임 복사본에 기록됩니다.
