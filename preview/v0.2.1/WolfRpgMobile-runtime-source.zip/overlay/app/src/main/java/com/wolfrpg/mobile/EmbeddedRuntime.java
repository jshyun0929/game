package com.wolfrpg.mobile;

import android.content.Context;
import android.content.Intent;

import com.winlator.XServerDisplayActivity;
import com.winlator.box64.Box64Preset;
import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.GraphicsDrivers;
import com.winlator.xenvironment.RootFSInstaller;

import org.json.JSONException;
import org.json.JSONObject;

import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

final class EmbeddedRuntime {
    static final int TOUCH_PROFILE = 21;
    private static final String GRAPHICS_DRIVER = GraphicsDrivers.TURNIP + "," + GraphicsDrivers.VIRGL;

    static File gameDirectory(Context context, String id) {
        return new File(context.getFilesDir(), "installed-games/" + id);
    }

    static Intent prepare(Context context, GameFiles source, String id, String renderer)
        throws IOException, JSONException {
        File game = gameDirectory(context, id);
        if (!game.isDirectory()) {
            GameFiles.Item executable = source.find(source.root, "Game.exe");
            if (executable == null || executable.directory()) {
                throw new IOException("게임 폴더에서 Game.exe를 찾지 못했어요.");
            }
            String architecture = source.inspect(executable);
            if (!architecture.startsWith("Windows x86") && !architecture.startsWith("Windows x64")) {
                throw new IOException("Windows x86 또는 x64용 Game.exe가 필요해요.");
            }
            installGame(source, game);
        }
        File executable = new File(game, "Game.exe");
        if (!executable.isFile()) throw new IOException("복사된 게임에서 Game.exe를 찾지 못했어요.");
        if (!RootFSInstaller.prepareForLaunch(context)) {
            throw new IOException("Windows 실행 환경을 설치할 수 없어요. 저장 공간을 확인하세요.");
        }

        ContainerManager manager = new ContainerManager(context);
        String drive = "D:" + game.getAbsolutePath();
        Container container = null;
        for (Container item : manager.getContainers()) {
            if (drive.equals(item.getDrives())) {
                container = item;
                break;
            }
        }
        if (container == null) {
            container = manager.createContainer(new JSONObject()
                .put("name", "WOLF " + id)
                .put("drives", drive)
                .put("screenSize", "960x540")
                .put("graphicsDriver", GRAPHICS_DRIVER)
                .put("dxwrapper", renderer)
                .put("box64Preset", Box64Preset.STABILITY));
            if (container == null) throw new IOException("이 게임의 Windows 환경을 만들 수 없어요.");
        } else {
            container.setGraphicsDriver(GRAPHICS_DRIVER);
            container.setDXWrapper(renderer);
            container.saveData();
        }
        return new Intent(context, XServerDisplayActivity.class)
            .putExtra("container_id", container.id)
            .putExtra("exec_path", executable.getAbsolutePath())
            .putExtra("wolf_controls", TOUCH_PROFILE);
    }

    private static void installGame(GameFiles source, File target) throws IOException {
        File parent = target.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("게임을 복사할 폴더를 만들 수 없어요.");
        File staging = new File(parent, target.getName() + "-copy");
        if (staging.exists()) remove(staging);
        if (!staging.mkdir()) throw new IOException("게임을 복사할 임시 폴더를 만들 수 없어요.");
        try {
            copyFolder(source, source.root, staging, 0);
            try (InputStream bytes = Files.newInputStream(new File(staging, "Game.exe").toPath())) {
                if (bytes.read() != 'M' || bytes.read() != 'Z') {
                    throw new IOException("Windows용 Game.exe를 찾지 못했어요. 실제 게임 폴더를 선택하세요.");
                }
            }
            Files.move(staging.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE);
        } finally {
            if (staging.exists()) remove(staging);
        }
    }

    private static void copyFolder(GameFiles source, Uri folder, File target, int depth)
        throws IOException {
        if (depth > 64) throw new IOException("게임 폴더 경로가 너무 깊어요.");
        byte[] buffer = new byte[65536];
        for (GameFiles.Item item : source.children(folder)) {
            String name = item.name();
            if (name == null || name.isEmpty() || name.equals(".") || name.equals("..")
                    || name.contains("/") || name.contains("\\")) throw new IOException("지원하지 않는 파일 이름이 있어요.");
            if (depth == 0 && name.equalsIgnoreCase("Game.exe")) name = "Game.exe";
            File destination = new File(target, name);
            if (destination.exists()) throw new IOException("중복된 게임 파일 이름이 있어요.");
            if (item.directory()) {
                if (!destination.mkdir()) throw new IOException("게임 하위 폴더를 만들 수 없어요.");
                copyFolder(source, item.uri(), destination, depth + 1);
            } else {
                try (InputStream input = source.open(item.uri());
                     FileOutputStream output = new FileOutputStream(destination)) {
                    int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                }
            }
        }
    }

    static void remove(File file) throws IOException {
        if (file.isDirectory() && !Files.isSymbolicLink(file.toPath())) {
            File[] children = file.listFiles();
            if (children == null) throw new IOException("게임 복사본을 열 수 없어요.");
            for (File child : children) remove(child);
        }
        Files.deleteIfExists(file.toPath());
    }
}
